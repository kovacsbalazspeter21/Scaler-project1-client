export default function CompanyMap() {
  // Itt használj pl. leaflet-et vagy Google Maps-et
  return (
    <div>
      <h2>Cég helyszínei</h2>
      <div style={{ width: 400, height: 300, background: '#eee' }}>
        {/* Itt jelenítsd meg a térképet, markerrel */}
        {/* Markerre kattintva: cím, Google Maps link */}
      </div>
    </div>
  );
}