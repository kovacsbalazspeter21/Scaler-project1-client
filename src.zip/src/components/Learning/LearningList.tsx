export default function LearningList() {
  // Itt fetch-eld a tananyagokat a backendről
  return (
    <div>
      <h2>Learning</h2>
      <ul>
        <li>Munkahelyi biztonság</li>
        <li>GDPR oktatás</li>
        {/* ... */}
      </ul>
    </div>
  );
}